---
title       : Elder Population (64+ years) Count in Chile (1992-2006)
subtitle    : + code chunks examples
author      : Pachamaltese
logo        : logo.jpg
job         : 
framework   : io2012        # {io2012, html5slides, shower, dzslides, ...}
highlighter : highlight.js  # {highlight.js, prettify, highlight}
hitheme     : tomorrow      # 
widgets     : []            # {mathjax, quiz, bootstrap}
mode        : selfcontained # {standalone, draft}
knit        : slidify::knit2slides
---

## Introduction

1. According to several studies in Chile we have an aging population and this means to change Public Policy guidelines. In 1995 we had 36 millions of elders in Latin America and by 2025 we will have 72+ millions of elders.

2. Therefore, it would be interesting to visualize how our elder population is aging in Chile.

3. This is a whole world concern as the world's population is aging.

4.  A good short article about aging population in Chile and Latin America is found in http://www.gerontologia.uchile.cl/docs/chien3.htm.

5. Because of this I decided to create a data product to illustrate how our elder population has evolved.

--- .class #id

## Data product

1. In https://github.com/pachamaltese/elder-population-chile you will find the complete application that I created for this project.

2. The repo is fully reproducible and the data is included because of reproducibility but the data should be downloaded from the Human Mortality Database (http://www.mortality.org/cgi-bin/hmd/country.php?cntr=CHL&level=1). There's a copyright restriction to use the data.

3. HMD also contains data for other countries and several variables (life expectancy, population increase, etc)

4. Here I'm displaying some code chunks to complete the assignment.

--- .class #id

## A simple code chunk

1. The plot posted in Shinyapps is too complex to be shown here. It was made using rCharts (http://rcharts.io/). Visit my project at https://pachamaltese.shinyapps.io/elder-population-chile/)

2. A  very simple example could be the following (I used R' cars dataset)

```r
 require(ggplot2)
 qplot(wt, mpg, data = mtcars)
```

<img src="assets/fig/simple-plot-1.png" title="plot of chunk simple-plot" alt="plot of chunk simple-plot" style="display: block; margin: auto;" />

--- .class #id

## An screenshot of my project

<div style='text-align: center;'>
    <img height='560' src='http://pachamaltese.github.io/application.png' />
</div>






