## Google IO 2012 HTML5 Slides

Authors: 
  Eric Bidelman <ebidel@gmail.com>
  Luke Mahé <lukem@google.com>
  
Modified By:
  Ramnath Vaidyanathan

URL: https://code.google.com/p/io-2012-slides

LICENSE: Apache 2.0
